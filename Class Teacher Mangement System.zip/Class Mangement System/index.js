const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const app = express();
const port = 3000;

app.use(express.json());

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/management_system');

// User schema/model
const userSchema = new mongoose.Schema({
  role: { type: String, enum: ['admin', 'teacher'], required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});
const User = mongoose.model('User', userSchema);

// Class schema/model
const classSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true }
});
const Class = mongoose.model('Class', classSchema);

// Student schema/model
const studentSchema = new mongoose.Schema({
  firstname: { type: String, required: true },
  lastname: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  admission: { type: String, required: true, unique: true },
  class: { type: String, required: true },
  dateCreated: { type: Date, default: Date.now }
});
const Student = mongoose.model('Student', studentSchema);

// Teacher schema/model (use main connection, not a separate DB)
const teacherSchema = new mongoose.Schema({
  firstname: { type: String, required: true },
  lastname: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  subject: { type: String }, // optional, keep for compatibility
  class: { type: String, required: true }, // <-- add this line
  password: { type: String, required: true },
  phone: { type: String },
  dateCreated: { type: Date, default: Date.now }
});
const Teacher = mongoose.model('Teacher', teacherSchema);

// Attendance schema/model
const attendanceSchema = new mongoose.Schema({
  admission: { type: String, required: true },
  firstname: { type: String, required: true },
  lastname: { type: String, required: true },
  class: { type: String, required: true },
  session: { type: String }, // optional
  term: { type: String },    // optional
  status: { type: String, enum: ['Present', 'Absent'], required: true },
  date: { type: String, required: true }, // yyyy-mm-dd
  dateCreated: { type: Date, default: Date.now }
});
const Attendance = mongoose.model('Attendance', attendanceSchema);

// Serve static files (including login.html)
app.use(express.static(__dirname));

// Registration endpoint (for testing/demo purposes)
app.post('/api/register', async (req, res) => {
  const { role, email, password } = req.body;
  if (!role || !email || !password) return res.status(400).json({ message: 'All fields required' });
  try {
    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ message: 'Email already registered' });
    await User.create({ role, email, password });
    res.status(201).json({ message: 'User registered' });
  } catch (err) {
    res.status(500).json({ message: 'Registration failed' });
  }
});

// Login endpoint
app.post('/api/login', async (req, res) => {
  const { role, email, password } = req.body;
  if (!role || !email || !password) return res.status(400).json({ message: 'All fields required' });
  try {
    const user = await User.findOne({ role, email, password });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });
    res.json({ message: 'Login successful', role: user.role });
  } catch (err) {
    res.status(500).json({ message: 'Login failed' });
  }
});


// Root route serves login.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

// Students API

// Get all students
app.get('/api/students', async (req, res) => {
  try {
    const students = await Student.find();
    res.json(students);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch students' });
  }
});

// Get a student by ID
app.get('/api/students/:id', async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) return res.status(404).json({ message: 'Student not found' });
    res.json(student);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch student' });
  }
});

// Add a new student
app.post('/api/students', async (req, res) => {
  const { firstname, lastname, email, admission, class: className } = req.body;
  if (!firstname || !lastname || !email || !admission || !className) {
    return res.status(400).json({ message: 'All fields required' });
  }
  try {
    const exists = await Student.findOne({ $or: [{ email }, { admission }] });
    if (exists) return res.status(409).json({ message: 'Student already exists' });
    const student = await Student.create({ firstname, lastname, email, admission, class: className });
    res.status(201).json(student);
  } catch (err) {
    res.status(500).json({ message: 'Failed to add student' });
  }
});

// Update a student
app.put('/api/students/:id', async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) return res.status(404).json({ message: 'Student not found' });
    const { firstname, lastname, email, admission, class: className } = req.body;
    if (firstname) student.firstname = firstname;
    if (lastname) student.lastname = lastname;
    if (email) student.email = email;
    if (admission) student.admission = admission;
    if (className) student.class = className;
    await student.save();
    res.json(student);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update student' });
  }
});

// Delete a student
app.delete('/api/students/:id', async (req, res) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);
    if (!student) return res.status(404).json({ message: 'Student not found' });
    res.json({ message: 'Student deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete student' });
  }
});

// Classes API

// Get all classes
app.get('/api/classes', async (req, res) => {
  try {
    const classes = await Class.find();
    res.json(classes);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch classes' });
  }
});

// Get a class by ID
app.get('/api/classes/:id', async (req, res) => {
  try {
    const cls = await Class.findById(req.params.id);
    if (!cls) return res.status(404).json({ message: 'Class not found' });
    res.json(cls);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch class' });
  }
});

// Add a new class
app.post('/api/classes', async (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ message: 'Class name required' });
  try {
    const exists = await Class.findOne({ name });
    if (exists) return res.status(409).json({ message: 'Class already exists' });
    const newClass = await Class.create({ name });

    // --- BEGIN: Create attendance records for all students in this class for today ---
    const students = await Student.find({ class: name });
    const today = new Date();
    const dateStr = today.toISOString().slice(0, 10);
    const attendanceRecords = students.map(s => ({
      admission: s.admission,
      firstname: s.firstname,
      lastname: s.lastname,
      class: s.class,
      status: 'Absent', // Default to Absent, or leave blank if you want
      date: dateStr
    }));
    if (attendanceRecords.length > 0) {
      // Use upsert to avoid duplicates if called multiple times
      const bulkOps = attendanceRecords.map(rec => ({
        updateOne: {
          filter: { admission: rec.admission, date: rec.date },
          update: { $setOnInsert: rec },
          upsert: true
        }
      }));
      await Attendance.bulkWrite(bulkOps);
    }
    // --- END: Create attendance records for all students in this class for today ---

    res.status(201).json(newClass);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create class' });
  }
});

// Update a class
app.put('/api/classes/:id', async (req, res) => {
  const { name } = req.body;
  try {
    const cls = await Class.findById(req.params.id);
    if (!cls) return res.status(404).json({ message: 'Class not found' });
    if (name) cls.name = name;
    await cls.save();
    res.json(cls);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update class' });
  }
});

// Delete a class
app.delete('/api/classes/:id', async (req, res) => {
  try {
    const cls = await Class.findByIdAndDelete(req.params.id);
    if (!cls) return res.status(404).json({ message: 'Class not found' });
    res.json({ message: 'Class deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete class' });
  }
});

// Teachers API

// Get all teachers or by email
app.get('/api/teachers', async (req, res) => {
  try {
    if (req.query.email) {
      // Find by email
      const teachers = await Teacher.find({ email: req.query.email });
      return res.json(teachers);
    }
    const teachers = await Teacher.find();
    res.json(teachers);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch teachers' });
  }
});

// Get a teacher by ID
app.get('/api/teachers/:id', async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);
    if (!teacher) return res.status(404).json({ message: 'Teacher not found' });
    res.json(teacher);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch teacher' });
  }
});

// Add a new teacher
app.post('/api/teachers', async (req, res) => {
  const { firstname, lastname, email, subject, password, phone, class: className } = req.body;
  // Accept either subject or className for compatibility
  const classField = className || subject;
  if (!firstname || !lastname || !email || !classField || !password) {
    return res.status(400).json({ message: 'All fields required' });
  }
  try {
    const exists = await Teacher.findOne({ email });
    if (exists) return res.status(409).json({ message: 'Teacher already exists' });
    const teacher = await Teacher.create({
      firstname,
      lastname,
      email,
      subject: classField, // for backward compatibility
      class: classField,   // for new field
      password,
      phone
    });
    // Also create a user for login if not exists
    const userExists = await User.findOne({ email, role: 'teacher' });
    if (!userExists) {
      await User.create({ role: 'teacher', email, password });
    }
    res.status(201).json(teacher);
  } catch (err) {
    res.status(500).json({ message: 'Failed to add teacher' });
  }
});

// Update a teacher
app.put('/api/teachers/:id', async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);
    if (!teacher) return res.status(404).json({ message: 'Teacher not found' });
    const { firstname, lastname, email, subject, class: className, phone } = req.body;
    if (firstname) teacher.firstname = firstname;
    if (lastname) teacher.lastname = lastname;
    if (email) teacher.email = email;
    if (subject) teacher.subject = subject;
    if (className) teacher.class = className;
    if (phone) teacher.phone = phone;
    await teacher.save();
    res.json(teacher);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update teacher' });
  }
});

// Delete a teacher
app.delete('/api/teachers/:id', async (req, res) => {
  try {
    // Find the teacher first
    const teacher = await Teacher.findById(req.params.id);
    if (!teacher) return res.status(404).json({ message: 'Teacher not found' });

    // Delete the teacher document
    await Teacher.deleteOne({ _id: teacher._id });

    // Delete the corresponding user account (role: teacher)
    await User.deleteOne({ email: teacher.email, role: 'teacher' });

    res.json({ message: 'Teacher and user deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete teacher' });
  }
});

// Attendance API

// Get all attendance records
app.get('/api/attendance', async (req, res) => {
  try {
    const records = await Attendance.find();
    res.json(records);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch attendance' });
  }
});

// Add a single attendance record
app.post('/api/attendance', async (req, res) => {
  const { admission, firstname, lastname, class: className, session, term, status, date } = req.body;
  if (!admission || !firstname || !lastname || !className || !status || !date) {
    return res.status(400).json({ message: 'All required fields must be provided' });
  }
  try {
    // Prevent duplicate for same student/date
    const exists = await Attendance.findOne({ admission, date });
    if (exists) return res.status(409).json({ message: 'Attendance already exists for this student and date' });
    const record = await Attendance.create({
      admission, firstname, lastname, class: className, session, term, status, date
    });
    res.status(201).json(record);
  } catch (err) {
    res.status(500).json({ message: 'Failed to add attendance' });
  }
});

// Add multiple attendance records (bulk)
app.post('/api/attendance/bulk', async (req, res) => {
  const { records } = req.body;
  if (!Array.isArray(records) || records.length === 0) {
    return res.status(400).json({ message: 'No attendance records provided' });
  }
  try {
    // Remove existing attendance for same students/date to avoid duplicates
    const bulkOps = [];
    for (const rec of records) {
      if (!rec.admission || !rec.firstname || !rec.lastname || !rec.class || !rec.status || !rec.date) continue;
      bulkOps.push({
        updateOne: {
          filter: { admission: rec.admission, date: rec.date },
          update: { $set: {
            admission: rec.admission,
            firstname: rec.firstname,
            lastname: rec.lastname,
            class: rec.class,
            session: rec.session || '',
            term: rec.term || '',
            status: rec.status,
            date: rec.date
          }},
          upsert: true
        }
      });
    }
    if (bulkOps.length === 0) return res.status(400).json({ message: 'No valid attendance records' });
    await Attendance.bulkWrite(bulkOps);
    res.status(201).json({ message: 'Attendance saved' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to save attendance' });
  }
});

// Get total attendance count
app.get('/api/attendance/total', async (req, res) => {
  try {
    const total = await Attendance.countDocuments();
    res.json({ total });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch total attendance' });
  }
});

// Update an attendance record
app.put('/api/attendance/:id', async (req, res) => {
  try {
    const record = await Attendance.findById(req.params.id);
    if (!record) return res.status(404).json({ message: 'Attendance record not found' });
    const { status } = req.body;
    if (status) record.status = status;
    await record.save();
    res.json(record);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update attendance' });
  }
});

// Delete an attendance record
app.delete('/api/attendance/:id', async (req, res) => {
  try {
    const record = await Attendance.findByIdAndDelete(req.params.id);
    if (!record) return res.status(404).json({ message: 'Attendance record not found' });
    res.json({ message: 'Attendance deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete attendance' });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
